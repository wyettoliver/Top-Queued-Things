<?php
	include 'connect.php';
	session_start();

	$id = $_SESSION['id'];
	$name = $_SESSION['email'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>Hello <?php echo $name; ?></p>
	<ul>
		<li>
			<a href="message.php">Home</a>
		</li>
	</ul>
	<table border="1">
		<tr>
			<td>
				Sent To
			</td>
			<td>
				Body
			</td>
			<td>
				Attachments
			</td>
		</tr>
			<?php
				$sql = "SELECT * FROM `mails` WHERE `sent_from` = $id;";
				$query = mysqli_query($conn, $sql);
				while ($row = mysqli_fetch_array($query)) {
					$sent_to = $row['sent_to'];
					$body = $row['body'];
					$attach = $row['attach'];
			?>
		<tr>
			<td>
				<?php echo $sent_to; ?>
			</td>
			<td>
				<?php echo $body; ?>
			</td>
			<td>
				<?php echo $attach; ?>
			</td>
		</tr>
			<?php
				}
			?>
	</table>
</body>
</html>