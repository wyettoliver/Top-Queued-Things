<?php
	session_start();

	$id = $_SESSION['id'];
	$name = $_SESSION['email'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="profile">
		<p>Hello <?php echo $name; ?></p>
		<ul>
			<li>
				<a href="message.php">Home</a>
			</li>
		</ul>
		<br>
		<table>
			<tr>
				<td>
					First Name
				</td>
				<td>
					Last Name
				</td>
				<td>
					Age
				</td>
				<td>
					Contact Number
				</td>
				<td>
					E-mail Address
				</td>
			</tr>
			<?php
				include 'connect.php';

				$sql = "SELECT a.fname, a.lname, a.age, a.number, b.email FROM `profile` a JOIN `users` b ON a.user_id = b.id AND b.id = $id;";
				$query = mysqli_query($conn, $sql);

				while($row = mysqli_fetch_array($query)){
					$fname = $row['fname'];
					$lname = $row['lname'];
					$age = $row['age'];
					$number = $row['number'];
					$email = $row['email'];
			?>
			<tr>
				<td>
					<?php echo $fname; ?>
				</td>
				<td>
					<?php echo $lname; ?>
				</td>
				<td>
					<?php echo $age; ?>
				</td>
				<td>
					<?php echo $number; ?>
				</td>
				<td>
					<?php echo $email; ?>
				</td>
			</tr>
			<?php
				}
			?>
		</table>
	</div>
</body>
</html>