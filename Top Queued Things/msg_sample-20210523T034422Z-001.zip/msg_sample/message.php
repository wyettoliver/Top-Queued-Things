<?php 
	session_start();

	$id = $_SESSION['id'];
	$email = $_SESSION['email'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		Hello <?php echo $email; ?>. Your user id is <?php echo $id; ?>
		<div class="menu">
			<ul>
				<li>
					<a href="profile.php">Profile</a>
				</li>
				<li>
					<a href="#" onclick="openMsg()">Create Message</a>
				</li>
				<li>
					<a href="inbox.php">Inbox</a>
				</li>
				<li>
					<a href="sent.php">Sent</a>
				</li>
				<li>
					<a href="logout.php">Logout</a>
				</li>
			</ul>
		</div>
	</div>
	<br>
	<div class="email" id="email">
		<form action="mail.php" method="POST" enctype="multipart/form-data">
			<div class="msg" id="msg">
				<div class="msg_head">
					<div class="msg_title">
						<label>To:</label>
						<input type="email" name="to" required=""><br>
						<label class="hidden">From:</label>
						<input class="hidden" type="text" name="from" value="<?php echo $id ?>">
					</div>
				</div>
				<div class="msg_body">
					<label>Message Body:</label><br>
					<textarea wrap="" cols="50" rows="5" name="field"></textarea><br>
					<input type="file" name="attach">
				</div>
				<div class="msg_foot">
					<input type="submit" name="send" value="Send">
					<input type="submit" name="close" value="Close" onclick="closeMsg()">
				</div>
			</div>
		</form>
	</div>
	<script type="text/javascript">
		function openMsg(){
			document.getElementById('msg').style.display = "block";
		}
		function closeMsg(){
			document.getElementById('msg').style.display = "none";
		}
	</script>
</body>
</html>