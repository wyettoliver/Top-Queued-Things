<?php
	include 'connect.php';
	session_start();

	$id = $_SESSION['id'];
	$name = $_SESSION['email'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>Hello <?php echo $name; ?></p>
	<ul>
		<li>
			<a href="message.php">Home</a>
		</li>
	</ul>
	<table border="1">
		<tr>
			<td>
				From
			</td>
			<td>
				Body
			</td>
			<td>
				Attach
			</td>
			<td colspan="2">
				Options
			</td>
		</tr>
			<?php
				$sql = "SELECT a.sent_to, b.email, a.body, a.attach FROM `mails` a JOIN `users` b ON a.sent_from = b.id WHERE a.sent_to = '$name';";
				$query = mysqli_query($conn, $sql);
				while ($row = mysqli_fetch_array($query)) {
					$sent_to = $row['sent_to'];
					$sent_from = $row['email'];
					$body = $row['body'];
					$attach = $row['attach'];
			?>
		<tr>
			<td>
				<?php echo $sent_from; ?>
			</td>
			<td>
				<?php echo $body; ?>
			</td>
			<td>
				<?php echo $attach; ?>
			</td>
			<td>
				<a href="#">Reply</a>
			</td>
			<td>
				<a href="#">Delete</a>
			</td>
		</tr>
			<?php
				}
			?>
	</table>
</body>
</html>