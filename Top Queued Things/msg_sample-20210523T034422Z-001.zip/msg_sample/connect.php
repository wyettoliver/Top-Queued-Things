<?php
	
	$conn = new mysqli("localhost", "root", "", "msg_db");
?>