<?php 
	include 'connect.php';

	
	if(isset($_POST['login'])){
		session_start();

		
		$email = $_POST['email'];
		$pwd = $_POST['pwd'];

		$sql = "SELECT * FROM users WHERE `email` = '$email' AND `password` = '$pwd'";

		if($query = mysqli_query($conn, $sql)){
			$row = mysqli_fetch_array($query);
				$id = $row['id'];
				$email = $row['email'];

				$_SESSION['id'] = $id;
				$_SESSION['email'] = $email;

			header("Location: message.php");
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="index.php" method="POST">
		<div class="login">
			<div class="login_head">
				<label>Login Form</label>
			</div>
			<div class="login_body">
				<label>Email Address:</label>
				<input type="email" name="email"><br>
				<label>Password:</label>
				<input type="password" name="pwd">
			</div>
			<div class="login_foot">
				<input type="submit" name="login" value="Login">
			</div>
		</div>
	</form>
</body>
</html>